// Your code here



// export for testing
module.exports = { greet, greetExpression };